import sys
import pygame
import time
import sqlite3  # для импортирования БД
import os
pygame.init()
size = width, height = 1920, 1080
screen = pygame.display.set_mode((size), pygame.RESIZABLE)
f2 = pygame.font.SysFont('serif', 130)
f1 = pygame.font.SysFont('serif', 40)
player_vel = 5
score = 0
n = 0
l = 0
destenation_y = 0
bul = 0
bul1 = 0
change = 0
time = 0
record = []
text3 = ''
smert = False
shooting = True
shooting1 = True
active = False
text = ''
done = False
is_jump = False
running = True
pygame.display.flip()
start = False
is_end = False
done = True
done1 = True
flag = False
falling = False
font = pygame.font.Font(None, 64)
clock = pygame.time.Clock()
input_box = pygame.Rect(35, 840, 280, 64)
color_inactive = pygame.Color('lightskyblue3')
color_active = pygame.Color('dodgerblue2')
color = color_inactive

def load_image(name, colorkey=None):
    fullname = os.path.join('sprites', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class Fon(pygame.sprite.Sprite):
    image = load_image("bomb.png")

    def __init__(self, *group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(*group)
        self.image = fon_sprite.image
        self.rect = self.image.get_rect()
        self.rect.x = 0
        self.rect.y = 0


class Platform(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(platform)
        self.image = load_image("platform.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 8
        self.rect.y = 849




class Platformu(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(platformu)
        self.image = load_image("platform_updown.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 0
        self.rect.y = 0


class Platform1(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(platform1)
        self.image = load_image("platform1.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 0
        self.rect.y = 634

class Platform2(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(platform2)
        self.image = load_image("platform2.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 0
        self.rect.y = 282

class Void(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(void)
        self.image = load_image("void.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 535
        self.rect.y = 624

void = pygame.sprite.Group()
void_sprite = Void()

class Ladder_mid1(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(ladder_mid1)
        self.image = load_image("ladder_mid1.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 140
        self.rect.y = 285



class Ladder(pygame.sprite.Sprite):
    image = load_image("ladder.png")

    def __init__(self, *group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(*group)
        self.image = ladder_sprite.image
        self.rect = self.image.get_rect()
        self.rect.x = -220
        self.rect.y = 150

class Ladder_end(pygame.sprite.Sprite):
    image = load_image("ladder_end.png")

    def __init__(self, *group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(*group)
        self.image = ladder_sprite_end.image
        self.rect = self.image.get_rect()
        self.rect.x = 315
        self.rect.y = 839



class Ladder_end2(pygame.sprite.Sprite):
    image = load_image("ladder_end.png")

    def __init__(self, *group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(*group)
        self.image = ladder_sprite_end2.image
        self.rect = self.image.get_rect()
        self.rect.x = 145
        self.rect.y = 266



class Ladder_end1(pygame.sprite.Sprite):
    image = load_image("ladder_end.png")

    def __init__(self, *group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(*group)
        self.image = ladder_sprite_end1.image
        self.rect = self.image.get_rect()
        self.rect.x = 1330
        self.rect.y = 626



class Portal(pygame.sprite.Sprite):
    image = load_image("portal.png")

    def __init__(self, *group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(*group)
        self.image = portal_sprite.image
        self.rect = self.image.get_rect()
        self.rect.x = 1868
        self.rect.y = 43



class Ladder_mid2(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(ladder_mid2)
        self.image = load_image("ladder_mid1.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 330
        self.rect.y = 860



class Ladder_mid3(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(ladder_mid3)
        self.image = load_image("ladder_midshort.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 1330
        self.rect.y = 634



class Ladder_corner(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(ladder_corner)
        self.image = load_image("ladder_corner.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 80
        self.rect.y = 310



class Start(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(sTart)
        self.image = load_image("Start_screen.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 0
        self.rect.y = 0



class End(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(end)
        self.image = load_image("end.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 0
        self.rect.y = 0



class Death(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(death)
        self.image = load_image("death.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 0
        self.rect.y = 0



class Bullet(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(bullet)
        self.image = load_image("bullet.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 1700
        self.rect.y = 730

    def update(self, direct):
        global shooting
        if shooting:
            self.rect.x -= 3
            if direct == 'hit':
                self.rect.x = 99999
        else:
            self.rect.x = -800




class Bullet1(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(bullet1)
        self.image = load_image("fireball.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 1450
        self.rect.y = 200

    def update(self, direct):
        global shooting1
        if shooting1:
            self.rect.x -= 3
            if direct == 'hit':
                self.rect.x = 99999
        else:
            self.rect.x = -800



class Heal(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(health)
        self.image = load_image("health.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 0
        self.rect.y = 85

    def update(self):
        if pygame.sprite.collide_mask(self, player_sprite):
            hp.update('health')
            self.rect.x = 999999

class Heal1(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(health)
        self.image = load_image("health_chain.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 1200
        self.rect.y = 200

    def update(self):
        if pygame.sprite.collide_mask(self, player_sprite):
            hp.update('health')
            self.rect.x = 999999

class Heal2(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(health)
        self.image = load_image("health.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 1450
        self.rect.y = 863

    def update(self):
        if pygame.sprite.collide_mask(self, player_sprite):
            hp.update('health')
            self.rect.x = 999999




class HP(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(hp)
        self.n = 0
        self.image = load_image("hp_bar1.png")
        self.arr = ("hp_bar1.png", "hp_bar2.png", "hp_bar3.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = -70
        self.rect.y = 836

    def update(self, direct):
        global is_jump, destenation_y, smert
        if direct == 'right':
            self.rect.x += 10
        if direct == 'left':
            self.rect.x -= 10
        if direct == 'up':
            self.rect.y -= 10
        if direct == 'down':
            self.rect.y += 10
        if is_jump:
            self.rect.y = destenation_y - 32
        if direct == 'hit':
            self.n += 3
            if self.n == 9:
                smert = True
            else:
                self.image = load_image(self.arr[self.n // 3])
        if direct == 'bit1':
            self.n += 3
            if self.n == 9:
                smert = True
            else:
                self.image = load_image(self.arr[self.n // 3])
        if direct == 'bit':
            self.n += 1
            if self.n == 9:
                smert = True
            else:
                self.image = load_image(self.arr[self.n // 3])
        if direct == 'health':
            if self.n < 3:
                pass
            else:
                self.image = load_image(self.arr[(self.n // 3) - 1])
                self.n -= 3



class Enemy(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(enemy)
        self.image = load_image("enemy1.png")
        self.arr = ["enemy1.png", "enemy1_knife.png"]
        self.arr_right = ["enemy1_right.png", "enemy2_knife.png"]
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 889
        self.rect.y = 867
        self.n = 0

    def update(self, direct):
        if direct == 'kill':
            self.image = load_image("grave.png")
        else:
            if self.rect.x >= direct:
                self.n += 1
                self.image = load_image(self.arr[((self.n // 20) % 2)])
            else:
                self.n += 1
                self.image = load_image(self.arr_right[((self.n // 20) % 2)])

class Enemy1(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(enemy)
        self.image = load_image("enemy2.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 1700
        self.rect.y = 650

    def update(self):
        self.image = load_image("grave.png")

class Enemy2(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(enemy)
        self.image = load_image("enemy1.png")
        self.arr = ["enemy1.png", "enemy1_knife.png"]
        self.arr_right = ["enemy1_right.png", "enemy2_knife.png"]
        self.rect = self.image.get_rect()
        self.n = 0
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 640
        self.rect.y = 434

    def update(self, direct):
        if direct == 'kill':
            self.image = load_image("grave.png")
        else:
            if self.rect.x >= direct:
                self.n += 1
                self.image = load_image(self.arr[((self.n // 20) % 2)])
            else:
                self.n += 1
                self.image = load_image(self.arr_right[((self.n // 20) % 2)])

class Enemy3(pygame.sprite.Sprite):

    def __init__(self):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(enemy)
        self.image = load_image("enemy_fireball.png")
        self.im = 'enemy_fireball'
        self.arr = ['enemy_fireball.png', 'enemy_fireball_shooting.png']
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.n = 0
        self.rect.x = 1500
        self.rect.y = 90

    def update(self, direct):
        if direct == 'kill':
            self.image = load_image("grave.png")
        else:
            if self.im == 'enemy_fireball':
                self.n += 1
                if self.n // 647 == 1:
                    self.image = load_image(self.arr[1])
                    self.im = self.arr[1]
                    self.n = 0
            else:
                self.n += 1
                if self.n // 50 == 1:
                    self.image = load_image(self.arr[0])
                    self.im = self.arr[0][:-4]
                    self.n = 0




class Player(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__(player)
        global destenation_y
        self.arr_cost_r = ["bomb.png", "bomb_2.png", "bomb3.png"]
        self.arr_cost_l = ["bomb_l.png", "bombl2.png", "bombl3.png"]
        self.image = load_image("bomb.png")
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 0
        self.rect.y = 868
        destenation_y = self.rect.y
        self.jumpcount = 10
        self.score = 0
        self.killed = True
        self.killed1 = True
        self.killed2 = True
        self.killed3 = True
        self.moving = 'right'
        self.n = 0

    def update(self, coord):
        global is_jump, is_end, score, n, l, falling, destenation_y, shooting, shooting1
        if not self.killed1:
            shooting = False
        if not self.killed3:
            shooting1 = False
        if pygame.sprite.collide_mask(self, enemy_sprite) and self.killed:
            enemy_sprite.update(self.rect.x)
            if (self.n // 77.5) % 3 == 2:
                self.n = 0
                hp.update('hit')
            self.n += 1
        if pygame.sprite.collide_mask(self, enemy_sprite1) and self.killed1:
            if (self.n // 77.5) % 3 == 2:
                self.n = 0
                hp.update('hit')
            self.n += 1
        if pygame.sprite.collide_mask(self, enemy_sprite2) and self.killed2:
            enemy_sprite2.update(self.rect.x)
            if (self.n // 77.5) % 3 == 2:
                self.n = 0
                hp.update('hit')
            self.n += 1
        if pygame.sprite.collide_mask(self, enemy_sprite3) and self.killed3:
            if (self.n // 77.5) % 3 == 2:
                self.n = 0
                hp.update('hit')
            self.n += 1
        if pygame.sprite.collide_mask(self, bullet_s):
            hp.update('bit')
            bullet.update('hit')
        if pygame.sprite.collide_mask(self, bullet_s1):
            hp.update('bit1')
            bullet1.update('hit')
        if pygame.sprite.collide_mask(self, ladder_sprite_corner):
            self.clibing = True
        if falling:
            if not is_jump:
                if pygame.sprite.collide_mask(self, platform_sprite) or \
                        pygame.sprite.collide_mask(self, platform_sprite2) or \
                        pygame.sprite.collide_mask(self, platform_sprite1) or \
                        pygame.sprite.collide_mask(self, platform_spriteu):
                    self.rect.y -= 10
                    hp.update('up')
                    falling = False
                else:
                    self.rect.y += 10
                    hp.update('down')
        if pygame.sprite.collide_mask(self, void_sprite):
            falling = True
        if pygame.sprite.spritecollideany(self, portal):
            is_end = True
        if coord == 'fight':
            if pygame.sprite.collide_mask(self, enemy_sprite) and self.killed:
                score += 1
                enemy_sprite.update('kill')
                self.killed = False
            if pygame.sprite.collide_mask(self, enemy_sprite1) and self.killed1:
                score += 1
                enemy_sprite1.update()
                self.killed1 = False
            if pygame.sprite.collide_mask(self, enemy_sprite2) and self.killed2:
                score += 1
                enemy_sprite2.update('kill')
                self.killed2 = False
            if pygame.sprite.collide_mask(self, enemy_sprite3) and self.killed3:
                score += 1
                enemy_sprite3.update('kill')
                self.killed3 = False
        if coord == 'left':
            self.moving = 'left'
            n += 1
            if n % 5 == 0:
                if self.moving == 'right':
                    self.image = load_image(self.arr_cost_r[l % 3])
                    l += 1
                else:
                    self.image = load_image(self.arr_cost_l[l % 3])
                    l += 1
            for i in range(10):
                self.rect.x -= 1
                self.moving = 'left'
            hp.update('left')
            if self.rect.x < 0 or pygame.sprite.collide_mask(self, platform_sprite) or \
                    pygame.sprite.collide_mask(self, platform_sprite2) or \
                    pygame.sprite.collide_mask(self, platform_sprite1) or \
                    pygame.sprite.collide_mask(self, ladder_sprite_corner):
                self.rect.x += 10
                hp.update('right')
        if coord == 'right':
            n += 1
            if n % 5 == 0:
                self.moving = 'right'
                if self.moving == 'right':
                    self.image = load_image(self.arr_cost_r[l % 3])
                    l += 1
                else:
                    self.image = load_image(self.arr_cost_l[l % 3])
                    l += 1
            self.rect.x += 10
            hp.update('right')
            if self.rect.x >= 1850 or pygame.sprite.collide_mask(self, platform_sprite) or \
                    pygame.sprite.collide_mask(self, platform_sprite2) or \
                    pygame.sprite.collide_mask(self, platform_sprite1) or \
                    pygame.sprite.collide_mask(self, ladder_sprite_corner):
                self.rect.x -= 10
                hp.update('left')
            self.moving = 'right'
        if coord == '':
            if pygame.sprite.spritecollideany(self, ladder_mid1) or pygame.sprite.spritecollideany(self, ladder_mid2) or\
                    pygame.sprite.spritecollideany(self, ladder_mid3):
                self.rect.y -= 10
                hp.update('up')
        if coord == 'down':
            if pygame.sprite.spritecollideany(self, ladder_mid1) or pygame.sprite.spritecollideany(self, ladder_mid2) or\
                    pygame.sprite.spritecollideany(self, ladder_mid3) \
                    or pygame.sprite.spritecollideany(self, ladder_end) or\
                    pygame.sprite.spritecollideany(self, ladder_end1) or\
                    pygame.sprite.spritecollideany(self, ladder_end2):
                self.rect.y += 10
                hp.update('down')
                if pygame.sprite.collide_mask(self, platform_sprite) or\
                        pygame.sprite.collide_mask(self, platform_sprite2) or\
                        pygame.sprite.collide_mask(self, platform_sprite1) or\
                        pygame.sprite.collide_mask(self, platform_spriteu):
                    self.rect.y -= 10
                    hp.update('up')
        if coord == 'jump':
            if self.jumpcount >= -10:
                if self.jumpcount > 0:
                    self.rect.y -= (self.jumpcount ** 2) // 4
                    destenation_y = self.rect.y
                    pygame.display.update()
                    hp.update('')
                    self.jumpcount -= 1
                    pygame.display.update()
                else:
                    self.rect.y += (self.jumpcount ** 2) // 4
                    destenation_y = self.rect.y
                    hp.update('')
                    self.jumpcount -= 1
                    pygame.display.update()
            else:
                is_jump = False
                self.jumpcount = 10

fon = pygame.sprite.Group()
fon_sprite = pygame.sprite.Sprite()
fon_sprite.image = load_image("fon.png")
Fon(fon)

platform = pygame.sprite.Group()
platform_sprite = Platform()

platformu = pygame.sprite.Group()
platform_spriteu = Platformu()

platform1 = pygame.sprite.Group()
platform_sprite1 = Platform1()

platform2 = pygame.sprite.Group()
platform_sprite2 = Platform2()

ladder_mid1 = pygame.sprite.Group()
ladder_sprite_mid1 = Ladder_mid1()

ladder = pygame.sprite.Group()
ladder_sprite = pygame.sprite.Sprite()
ladder_sprite.image = load_image("ladder.png")
Ladder(ladder)

ladder_end = pygame.sprite.Group()
ladder_sprite_end = pygame.sprite.Sprite()
ladder_sprite_end.image = load_image("ladder_end.png")
Ladder_end(ladder_end)

ladder_end2 = pygame.sprite.Group()
ladder_sprite_end2 = pygame.sprite.Sprite()
ladder_sprite_end2.image = load_image("ladder_end.png")
Ladder_end2(ladder_end2)

ladder_end1 = pygame.sprite.Group()
ladder_sprite_end1 = pygame.sprite.Sprite()
ladder_sprite_end1.image = load_image("ladder_end.png")
Ladder_end1(ladder_end1)

portal = pygame.sprite.Group()
portal_sprite = pygame.sprite.Sprite()
portal_sprite.image = load_image("portal.png")
Portal(portal)

ladder_mid2 = pygame.sprite.Group()
ladder_sprite_mid2 = Ladder_mid2()

ladder_mid3 = pygame.sprite.Group()
ladder_sprite_mid3 = Ladder_mid3()

ladder_corner = pygame.sprite.Group()
ladder_sprite_corner = Ladder_corner()

sTart = pygame.sprite.Group()
start_sprite = Start()

end = pygame.sprite.Group()
end_sptite = End()

death = pygame.sprite.Group()
death_s = Death()

bullet = pygame.sprite.Group()
bullet_s = Bullet()

bullet1 = pygame.sprite.Group()
bullet_s1 = Bullet1()

health = pygame.sprite.Group()
health_s = Heal()
health_s1 = Heal1()
health_s2 = Heal2()

hp = pygame.sprite.Group()
hp_bar = HP()

enemy = pygame.sprite.Group()
enemy_sprite = Enemy()
enemy_sprite1 = Enemy1()
enemy_sprite2 = Enemy2()
enemy_sprite3 = Enemy3()

player = pygame.sprite.Group()
player_sprite = Player()

while running:
    if start:
        if not is_end:
            if not smert:
                pygame.display.flip()
                screen.fill((0, 0, 0))
                fon.draw(screen)
                platform.draw(screen)
                platform1.draw(screen)
                platform2.draw(screen)
                platformu.draw(screen)
                ladder.draw(screen)
                player.draw(screen)
                portal.draw(screen)
                enemy.draw(screen)
                hp.draw(screen)
                health.draw(screen)
                bullet.draw(screen)
                bullet1.draw(screen)
                bullet.update(123)
                bullet1.update(123)
                enemy_sprite3.update(123)
                time += clock.tick() / 1000
                text2 = f1.render(str(time)[0:5], False,
                                  (255, 255, 255))
                screen.blit(text2, (10, 10))
                con = sqlite3.connect("leaderboard.sqlite")  # импортируем базу данных
                cur = con.cursor()
                c = cur.execute("""SELECT * FROM highscore""").fetchall()  # выбираем все данные из таблицы
                c = sorted(c, key=lambda score: float(score[1]), reverse=True)
                c = c[::-1]
                for i in c:
                    if done1:
                        string = i[0] + ': ' + i[1]  # создаем строку с  именем и счетом пользователя
                        if text in string:
                            text1 = f1.render('Ваш рекорд:' + i[1], False,
                                              (255, 255, 255))
                            done1 = False
                        else:
                            text1 = f1.render('Ваш рекорд:' + str(time)[:5], False,
                                              (255, 255, 255))
                    screen.blit(text1, (150, 10))
                if is_jump:
                    player.update('jump')
                if shooting:
                    if (bul // 77.5) // 6 == 1:
                        bul = 0
                        bullet_s = Bullet()
                    bul += 1
                if shooting1:
                    if (bul1 // 77.5) // 9 == 1:
                        bul1 = 0
                        bullet_s1 = Bullet1()
                    bul1 += 1
                player.update(123)
                for event in pygame.event.get():
                    player.update('rty')
                    if event.type == pygame.QUIT:
                        running = False
                    if pygame.key.get_pressed()[pygame.K_a]:
                        player.update('left')
                    if pygame.key.get_pressed()[pygame.K_d]:
                        player.update('right')
                    if pygame.key.get_pressed()[pygame.K_UP]:
                        player.update('fight')
                    if not is_jump:
                        if pygame.key.get_pressed()[pygame.K_s]:
                            player.update('down')
                        if pygame.key.get_pressed()[pygame.K_w]:
                            player.update('')
                        if pygame.key.get_pressed()[pygame.K_SPACE]:
                            player.update('jump')
                            is_jump = True
                    pygame.display.flip()
                health.update()
            else:
                pygame.display.flip()
                screen.fill((0, 0, 0))
                death.draw(screen)
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
        else:
            pygame.display.flip()
            screen.fill((0, 0, 0))
            fon.draw(screen)
            text2 = f2.render('Молодец, ты убил ' + str(score) + ' врагов!', False,
                              (255, 255, 255))
            text1 = f2.render('За ' + str(time)[0:5] + 'с', False,
                              (255, 255, 255))
            screen.blit(text2, (200, 400))
            screen.blit(text1, (100, 600))
            if done:
                con = sqlite3.connect("leaderboard.sqlite")  # импортируем базу данных
                cur = con.cursor()
                c = cur.execute("""SELECT * FROM highscore""").fetchall()  # выбираем все данные из ddddddddтаблицы
                c = sorted(c, key=lambda score: float(score[1]), reverse=True)
                cur.close()
                for i in c:
                    if i[0] == text and float(i[1]) > time:
                        text3 = f1.render('Твой рекорд:' + str(time)[0:5], False,
                                          (255, 255, 255))
                        sqlite_connection = sqlite3.connect('leaderboard.sqlite')  # импортируем базу данных
                        cursor = sqlite_connection.cursor()
                        sqlite_insert_query = cursor.execute("""DELETE from highscore
                        where score > ? AND name = ?""", (time, text)).fetchall()
                        sqlite_connection.commit()
                        cursor.close()


                        sqlite_connection = sqlite3.connect('leaderboard.sqlite')  # импортируем базу данных
                        cursor = sqlite_connection.cursor()
                        sqlite_insert_query = """INSERT INTO highscore VALUES ('""" + text + "', '" + str(time)[
                                                                                                      0:5] + "')"
                        count = cursor.execute(
                            sqlite_insert_query)  # добавляем в таблицу пользователей и их счета пользователя и счет
                        sqlite_connection.commit()
                        cursor.close()
                        sqlite_connection.close()
                        screen.blit(text3, (300, 300))
                        flag = True
                    elif i[0] == text and float(i[1]) <= time:
                        text3 = f2.render('Твой рекорд:' + str(i[1]) + 'c', False,
                                          (255, 255, 255))
                        screen.blit(text3, (300, 300))
                        flag = True
                if not flag:
                    text3 = f2.render('Твой рекорд:' + str(time)[:5] + 'c', False,
                                        (255, 255, 255))
                    screen.blit(text3, (300, 300))
                    sqlite_connection = sqlite3.connect('leaderboard.sqlite')  # импортируем базу данных
                    cursor = sqlite_connection.cursor()
                    sqlite_insert_query = """INSERT INTO highscore VALUES ('""" + text + "', '" + str(time)[
                                                                                                  0:5] + "')"
                    count = cursor.execute(
                        sqlite_insert_query)  # добавляем в таблицу пользователей и их счета пользователя и счет
                    sqlite_connection.commit()
                    cursor.close()
                    pygame.display.flip()
                done = False
            if not flag:
                text3 = f2.render('Твой рекорд:' + str(time)[:5] + 'c', False,
                                    (255, 255, 255))
            screen.blit(text3, (700, 600))
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
    else:
        pygame.display.flip()
        screen.fill((0, 0, 0))
        sTart.draw(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                # If the user clicked on the input_box rect.
                if input_box.collidepoint(event.pos):
                    # Toggle the active variable.
                    active = not active
                else:
                    active = False
                # Change the current color of the input box.
                color = color_active if active else color_inactive
            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        start = True
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode
        txt_surface = font.render(text, True, color)
        width = 400
        input_box.w = width
        screen.blit(txt_surface, (input_box.x+5, input_box.y+5))
        pygame.draw.rect(screen, color, input_box, 5)
        pygame.display.flip()
        clock.tick(30)